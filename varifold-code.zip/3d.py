import open3d as o3d
import numpy as np
fixed_vert_list = np.load('list/liver/old.npy')
fixed_face_list = np.load('list/liver/fixed-face.npy')
mesh = o3d.geometry.TriangleMesh()
mesh.vertices = o3d.utility.Vector3dVector(fixed_vert_list)  # 设置顶点
mesh.triangles = o3d.utility.Vector3iVector(fixed_face_list) # 设置三角形面


# 可选：计算顶点法线（泊松重建需要法线信息）
mesh.compute_vertex_normals()
#法线取负有透视效果
mesh.vertex_normals = o3d.utility.Vector3dVector(-np.asarray(mesh.vertex_normals))

# 方法1：直接使用网格顶点（可能点太少，重建效果差）
#pcd = mesh.sample_points_uniformly(number_of_points=1000)

# 方法2：从网格表面均匀采样点（推荐）
pcd = mesh.sample_points_poisson_disk(number_of_points=2000)  # 采样10000个点


# 参数说明：
# depth: 重建的八叉树深度（值越大细节越多，但计算量越大，通常8-10）
# scale: 网格缩放比例（默认1.1）
# linear_fit: 是否优化网格顶点位置（默认True）
poisson_mesh, densities = o3d.geometry.TriangleMesh.create_from_point_cloud_poisson(pcd, depth=7, linear_fit=True)

# 可选：过滤低密度顶点（去除重建的离群点）
#vertices_to_remove = densities < np.quantile(densities, 0.01)
#poisson_mesh.remove_vertices_by_mask(vertices_to_remove)


print("原始网格：")
print(mesh)
print("泊松重建后的网格：")
print(poisson_mesh)

poisson_mesh.compute_vertex_normals()
poisson_mesh.orient_triangles()  



#---------------------------------------------------------------------------------------------
fixed_vert_list2 = np.load('list/liver/moving-vert.npy')
fixed_face_list2 = np.load('list/liver/moving-face.npy')
mesh2 = o3d.geometry.TriangleMesh()
mesh2.vertices = o3d.utility.Vector3dVector(fixed_vert_list2)  # 设置顶点
mesh2.triangles = o3d.utility.Vector3iVector(fixed_face_list2) # 设置三角形面


# 可选：计算顶点法线（泊松重建需要法线信息）
mesh2.compute_vertex_normals()
#法线取负有透视效果
mesh2.vertex_normals = o3d.utility.Vector3dVector(-np.asarray(mesh2.vertex_normals))

# 方法1：直接使用网格顶点（可能点太少，重建效果差）
#pcd = mesh.sample_points_uniformly(number_of_points=1000)

# 方法2：从网格表面均匀采样点（推荐）
pcd2 = mesh2.sample_points_poisson_disk(number_of_points=2000)  # 采样10000个点


# 参数说明：
# depth: 重建的八叉树深度（值越大细节越多，但计算量越大，通常8-10）
# scale: 网格缩放比例（默认1.1）
# linear_fit: 是否优化网格顶点位置（默认True）
poisson_mesh2, densities2 = o3d.geometry.TriangleMesh.create_from_point_cloud_poisson(pcd2, depth=7, linear_fit=False)

# 可选：过滤低密度顶点（去除重建的离群点）
#vertices_to_remove = densities < np.quantile(densities, 0.01)
#poisson_mesh.remove_vertices_by_mask(vertices_to_remove)


print("原始网格：")
print(mesh2)
print("泊松重建后的网格：")
print(poisson_mesh2)

poisson_mesh2.compute_vertex_normals()
poisson_mesh2.orient_triangles()  

poisson_mesh.paint_uniform_color([0,1,1])
poisson_mesh2.paint_uniform_color([1,1,0])
mesh.paint_uniform_color([0,1,1])
mesh2.paint_uniform_color([1,1,0])
#o3d.visualization.draw_geometries([poisson_mesh,poisson_mesh2])
#o3d.visualization.draw_geometries([poisson_mesh])
o3d.visualization.draw_geometries([poisson_mesh2])
    
    