import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
import numbers


#此函数用凸松弛的方法计算mse，作为损失函数的一部分
def newmse(verts_X_tensor, verts_Y_tensor,area_X_tensor,area_Y_tensor, sigma_pos = 0.75):
    dist_vector = torch.add(torch.unsqueeze(verts_X_tensor,1), torch.unsqueeze(verts_Y_tensor,0), alpha = -1)
    dist_square = torch.pow(torch.norm(dist_vector, p=2, dim=2, keepdim=True),2)
    exp_index = -1 / sigma_pos ** 2 * dist_square 
    k_pos = torch.squeeze(torch.exp(exp_index))
    area_multiply = torch.matmul(area_X_tensor,torch.transpose(area_Y_tensor, dim0 = 1, dim1 = 0))  
    element =  k_pos*area_multiply
    elementsum1 =0.00000001+ torch.sum(element,dim=0)
    elementsum2 =0.00000001+ torch.sum(element,dim=1)
    elementsum1 = -6*torch.log(elementsum1)
    elementsum2 =-6*torch.log(elementsum2)
    #elementsum1 = 0.15*torch.pow(elementsum1,-1)
    #elementsum2 =0.15*torch.pow(elementsum2,-1)
    sum1 = torch.sum(elementsum1)
    sum2 = torch.sum(elementsum2)
    return sum1+sum2
    


#此函数用于计算并返回位移场
def transform_vertex(verts_list_tensor_original, size, flow, device = "cuda"):
    vectors = [ torch.arange(0, s) for s in size ] 
    grids = torch.meshgrid(vectors)
    grid  = torch.stack(grids) # y, x, z
    grid  = torch.unsqueeze(grid, 0)  #add batch
    grid = grid.type(torch.FloatTensor).to(device)
    transform = grid + flow

    verts_list_tensor_original = verts_list_tensor_original.squeeze()
    verts_list_transformed_tensor = verts_list_tensor_original.clone().float()
    verts_list_tensor = verts_list_tensor_original.clone().float()
    #print(verts_list_tensor.shape)
    verts_list_tensor = verts_list_tensor.unsqueeze(dim = -1).unsqueeze(dim = -1).unsqueeze(dim = -1)
    shape = transform.shape[2:]
    #print(shape)
    #print(verts_list_tensor.shape)
    for i in range(len(shape)):
        verts_list_tensor[:,i,...] = 2*(verts_list_tensor[:,i,...]/(shape[i]-1) - 0.5)

    if len(shape) == 2:
        verts_list_tensor = verts_list_tensor.permute(0, 2, 3, 1) 
        verts_list_tensor = verts_list_tensor[..., [1,0]]
    elif len(shape) == 3:
        verts_list_tensor = verts_list_tensor.permute(0, 2, 3, 4, 1) 
        verts_list_tensor = verts_list_tensor[..., [2,1,0]]

    #print(verts_list_tensor)

    for k in range(verts_list_tensor.shape[0]):
        grid = verts_list_tensor[k].unsqueeze(dim = 0)
        verts_list_transformed_tensor[k,:] = torch.nn.functional.grid_sample(transform, grid, mode='bilinear', align_corners=True).squeeze()#align_corners=None
    
    return verts_list_transformed_tensor



#由三角网格的点和面返回重心，法向，面积
def faces_information(verts_list_tensor, faces_list_tensor):
    '''
    Calculate the barycenter, normal vector and area of the face.
    '''
    verts_list_tensor = verts_list_tensor.squeeze()
    faces_list_tensor = faces_list_tensor.squeeze()
    
    face_number = faces_list_tensor.shape[0]
    verts = torch.zeros([face_number,3])
    normals = torch.zeros([face_number,3])
    areas = torch.zeros([face_number,1])
    
    # 似乎可以通过改变张量形状or复制张量替换掉for循环
    for i in range(face_number):
        #print(faces_list_tensor.shape)
        #print(faces_list_tensor[0,i,0])
        #print(type(faces_list_tensor[0,i,0]))
        #print(faces_list_tensor[0,i,0].int())
        #print(type(faces_list_tensor[0,i,0].int().item()))
        vertex_0 = verts_list_tensor[faces_list_tensor[i,0].int().item()]
        vertex_1 = verts_list_tensor[faces_list_tensor[i,1].int().item()]
        vertex_2 = verts_list_tensor[faces_list_tensor[i,2].int().item()]
        verts[i] = (vertex_0 + vertex_1 + vertex_2) / 3
        vector_1 = vertex_1 - vertex_0
        vector_2 = vertex_2 - vertex_0
        vector_normal = torch.cross(vector_1,vector_2)
        vector_length = torch.dot(vector_normal,vector_normal) ** 0.5
        #print(vertex_0,vertex_1,vertex_2)
        #print(vector_normal)
        if vector_length != 0:
            normals[i] = vector_normal / vector_length
        else:
            # print(i)
            pass
        areas[i] = vector_length * 0.5
        
    return verts, normals, areas



#由三角网格的点和面返回重心，法向，面积，曲率
def dy_faces_information(verts_list_tensor, faces_list_tensor):

    verts_list_tensor = verts_list_tensor.squeeze()
    faces_list_tensor = faces_list_tensor.squeeze()
    
    face_number = faces_list_tensor.shape[0]
    verts = torch.zeros([face_number,3])
    normals = torch.zeros([face_number,3])
    areas = torch.zeros([face_number,1])
    
    #计算曲率的代码#############
    vert_number=verts_list_tensor.shape[0]
    curvatures=torch.zeros([vert_number,1])
    cur_face=torch.zeros([face_number,1])
    for i in range(vert_number):
        A=0
        theta=0
        for j in range(face_number):
            v0=faces_list_tensor[j,0].int().item()
            v1=faces_list_tensor[j,1].int().item()
            v2=faces_list_tensor[j,2].int().item()
            if i==v0 :
                vertex_0 = verts_list_tensor[faces_list_tensor[j,0].int().item()]
                vertex_1 = verts_list_tensor[faces_list_tensor[j,1].int().item()]
                vertex_2 = verts_list_tensor[faces_list_tensor[j,2].int().item()]
                vector_1 = vertex_1 - vertex_0
                vector_2 = vertex_2 - vertex_0
                vector_3 = vertex_1 - vertex_2
                a=torch.dot(vector_1,vector_1) ** 0.5
                b=torch.dot(vector_2,vector_2) ** 0.5
                c=torch.dot(vector_3,vector_3) ** 0.5
                d=torch.dot(vector_1,vector_2) 
                vector_normal = torch.cross(vector_1,vector_2)
                vector_length = torch.dot(vector_normal,vector_normal) ** 0.5
                vector_length=vector_length.item()
                area=vector_length * 0.5
                d=d.item()
                a=a.item()
                b=b.item()
                c=c.item()
                A=A+(area*(a+b-c)/(a+b+c))
                #A=A+area/3
                if d>=a*b:
                    d=a*b
                if d<=-a*b:
                    d=-a*b
                if a*b==0:
                    d=0
                    a=1
                    b=1
                theta=theta+math.acos(d/((a*b)))
            if i==v1 :
                vertex_0 = verts_list_tensor[faces_list_tensor[j,1].int().item()]
                vertex_1 = verts_list_tensor[faces_list_tensor[j,0].int().item()]
                vertex_2 = verts_list_tensor[faces_list_tensor[j,2].int().item()]
                vector_1 = vertex_1 - vertex_0
                vector_2 = vertex_2 - vertex_0
                vector_3=vertex_1 - vertex_2
                a=torch.dot(vector_1,vector_1) ** 0.5
                b=torch.dot(vector_2,vector_2) ** 0.5
                c=torch.dot(vector_3,vector_3) ** 0.5
                d=torch.dot(vector_1,vector_2)
                vector_normal = torch.cross(vector_1,vector_2)
                vector_length = torch.dot(vector_normal,vector_normal) ** 0.5
                vector_length=vector_length.item()
                area=vector_length * 0.5
                d=d.item()
                a=a.item()
                b=b.item()
                c=c.item()
                A=A+(area*(a+b-c)/(a+b+c)) 
                #A=A+area/3
                if d>=a*b:
                    d=a*b
                if d<=-a*b:
                    d=-a*b
                if a*b==0:
                    d=0
                    a=1
                    b=1
                theta=theta+math.acos(d/((a*b))) 
            if i==v2 :
                vertex_0 = verts_list_tensor[faces_list_tensor[j,2].int().item()]
                vertex_1 = verts_list_tensor[faces_list_tensor[j,0].int().item()]
                vertex_2 = verts_list_tensor[faces_list_tensor[j,1].int().item()]
                vector_1 = vertex_1 - vertex_0
                vector_2 = vertex_2 - vertex_0
                vector_3 = vertex_1 - vertex_2
                a=torch.dot(vector_1,vector_1) ** 0.5
                b=torch.dot(vector_2,vector_2) ** 0.5
                c=torch.dot(vector_3,vector_3) ** 0.5
                d=torch.dot(vector_1,vector_2) 
                vector_normal = torch.cross(vector_1,vector_2)
                vector_length = torch.dot(vector_normal,vector_normal) ** 0.5
                vector_length=vector_length.item()
                area=vector_length * 0.5
                d=d.item()
                a=a.item()
                b=b.item()
                c=c.item()
                A=A+(area*(a+b-c)/(a+b+c))
                #A=A+area/3
                if d>=a*b:
                    d=a*b
                if d<=-a*b:
                    d=-a*b
                if a*b==0:
                    d=0
                    a=1
                    b=1
                theta=theta+math.acos(d/((a*b)))
        if A==0:
            A=10000        
        curvatures[i]=(2*3.1416-theta)/(A)
          #计算曲率的代码############################
    for i in range(face_number):
        vertex_0 = verts_list_tensor[faces_list_tensor[i,0].int().item()]
        vertex_1 = verts_list_tensor[faces_list_tensor[i,1].int().item()]
        vertex_2 = verts_list_tensor[faces_list_tensor[i,2].int().item()]
        verts[i] = (vertex_0 + vertex_1 + vertex_2) / 3
        a=curvatures[faces_list_tensor[i,0].int().item()]
        b=curvatures[faces_list_tensor[i,1].int().item()]
        c=curvatures[faces_list_tensor[i,2].int().item()]
        cur_face[i]=(a+b+c)/3
        vector_1 = vertex_1 - vertex_0
        vector_2 = vertex_2 - vertex_0
        vector_normal = torch.cross(vector_1,vector_2)
        vector_length = torch.dot(vector_normal,vector_normal) ** 0.5
        
        if vector_length != 0:
            normals[i] = vector_normal / vector_length
        else:
            pass
        areas[i] = vector_length * 0.5
     
    return verts, normals, areas,cur_face




#此函数进行核函数选取和计算
def surface_inner_product(verts_X_tensor, verts_Y_tensor, 
                     normal_X_tensor, normal_Y_tensor, 
                     area_X_tensor,area_Y_tensor,
                     radial_kernel = 'Gaussian', spherical_kernel = 'currents',
                     sigma_pos = 1.5, sigma_or = 0.5):
    '''
    calculate the inner product of two surfaces (option: current, unoriented varifold, oriented varifold)
    radial_kernel = 'Gaussian', 'Cauchy'
    spherical_kernel = 'currents', 'unoriented varifolds', 'oriented varifolds', 'distributions'
    '''
    
    # k_pos
    dist_vector = torch.add(torch.unsqueeze(verts_X_tensor,1), torch.unsqueeze(verts_Y_tensor,0), alpha = -1)
    dist_square = torch.pow(torch.norm(dist_vector, p=2, dim=2, keepdim=True),2)
    if radial_kernel == 'Gaussian':
        exp_index = -1 / sigma_pos ** 2 * dist_square #能不能直接求内积
        k_pos = torch.squeeze(torch.exp(exp_index))
    elif radial_kernel == 'Cauchy':
        k_pos = 1 / (1 + 1 / sigma_pos ** 2 * dist_square)

    # k_or
    normal_product = torch.matmul(normal_X_tensor,torch.transpose(normal_Y_tensor, dim0 = 1, dim1 = 0))
    
    if spherical_kernel == 'currents':
        k_or = normal_product 
    elif spherical_kernel == 'unoriented varifolds':
        k_or = torch.pow(normal_product,2)
    elif spherical_kernel == 'oriented varifolds':
        k_or = torch.exp( 2 / sigma_or ** 2 * normal_product) # oriented varifolds     dy这里改动了
    elif spherical_kernel == 'distributions':
        k_or = torch.ones(normal_product.shape)

    # area_multiply
    area_multiply = torch.matmul(area_X_tensor,torch.transpose(area_Y_tensor, dim0 = 1, dim1 = 0))

    element =  k_pos * k_or * area_multiply
    elements_sum = torch.sum(element)
    
    # del element, k_pos, k_or, area_multiply 
    return elements_sum



#此函数是嵌入曲率后的核函数选取和计算
def dy_surface_inner_product(verts_X_tensor, verts_Y_tensor, 
                     normal_X_tensor, normal_Y_tensor,
                             cur_X_tensor,cur_Y_tensor,   
                     area_X_tensor,area_Y_tensor,      
                     radial_kernel = 'Gaussian', spherical_kernel = 'currents',
                     sigma_pos = 1.5, sigma_or = 0.5):
    
    
    # k_pos
    dist_vector = torch.add(torch.unsqueeze(verts_X_tensor,1), torch.unsqueeze(verts_Y_tensor,0), alpha = -1)
    dist_square = torch.pow(torch.norm(dist_vector, p=2, dim=2, keepdim=True),2)
    if radial_kernel == 'Gaussian':
        exp_index = -1 / sigma_pos ** 2 * dist_square 
        k_pos = torch.squeeze(torch.exp(exp_index))
    elif radial_kernel == 'Cauchy':
        k_pos = 1 / (1 + 1 / sigma_pos ** 2 * dist_square)
        k_pos = torch.squeeze(k_pos)

    # k_or
    normal_product = torch.matmul(normal_X_tensor,torch.transpose(normal_Y_tensor, dim0 = 1, dim1 = 0))
    
    if spherical_kernel == 'currents':
        k_or = normal_product 
    elif spherical_kernel == 'unoriented varifolds':
        k_or = torch.pow(normal_product,2)
    elif spherical_kernel == 'oriented varifolds':
        k_or = torch.exp( 2 / sigma_or ** 2 * normal_product) # oriented varifolds     
    elif spherical_kernel == 'distributions':
        k_or = torch.ones(normal_product.shape)
        
    #k_cur
    a = torch.add(torch.unsqueeze(cur_X_tensor,1), torch.unsqueeze(cur_Y_tensor,0), alpha = -1)
    b= torch.pow(a,2)  
    c = -(0.5)* b 
    k_cur = torch.squeeze(torch.exp(c))

    # area_multiply
    area_multiply = torch.matmul(area_X_tensor,torch.transpose(area_Y_tensor, dim0 = 1, dim1 = 0)) 
    element =  k_pos * k_or *k_cur* area_multiply
    #element =  k_pos*k_or*area_multiply
    elements_sum = torch.sum(element) 
    return elements_sum





#计算varifold的二重积分
def surface_distance(verts_X_tensor, verts_Y_tensor, 
                     normal_X_tensor, normal_Y_tensor, 
                     area_X_tensor,area_Y_tensor,
                     radial_kernel = 'Gaussian', spherical_kernel = 'oriented varifolds',
                     sigma_pos = 1.5, sigma_or = 0.5):
    '''
    calculate the distance of two surfaces (option: current, unoriented varifold, oriented varifold)
    radial_kernel = 'Gaussian', 'Cauchy'
    spherical_kernel = 'currents', 'unoriented varifolds', 'oriented varifolds', 'distributions'
    '''
    
    ## W_xy
    W_xy = surface_inner_product(verts_X_tensor, verts_Y_tensor,
                                 normal_X_tensor, normal_Y_tensor,
                                 area_X_tensor,area_Y_tensor,
                                 radial_kernel = radial_kernel, spherical_kernel = spherical_kernel,
                                 sigma_pos=sigma_pos , sigma_or=sigma_or  )
    
    ## W_xx
    W_xx = surface_inner_product(verts_X_tensor, verts_X_tensor,
                                 normal_X_tensor, normal_X_tensor, 
                                 area_X_tensor,area_X_tensor,
                                 radial_kernel = radial_kernel, spherical_kernel = spherical_kernel,
                                 sigma_pos=sigma_pos , sigma_or=sigma_or  )

    ## W_yy
    W_yy = surface_inner_product(verts_Y_tensor, verts_Y_tensor,
                                 normal_Y_tensor, normal_Y_tensor,
                                 area_Y_tensor,area_Y_tensor,
                                 radial_kernel = radial_kernel, spherical_kernel = spherical_kernel,
                                 sigma_pos=sigma_pos , sigma_or=sigma_or  )

    Dist_xy = W_xx + W_yy - 2 * W_xy
    Dist_xy = Dist_xy*(((W_xx)/(W_yy))**(0.7))
    print('var:',Dist_xy)
    m=newmse(verts_X_tensor,verts_Y_tensor,area_X_tensor,area_Y_tensor)
    print('90',m)
    Dist_xy=m
    
    return Dist_xy



#含曲率的varifold积分
def dy_surface_distance(verts_X_tensor, verts_Y_tensor, 
                     normal_X_tensor, normal_Y_tensor, 
                        cur_X_tensor,cur_Y_tensor,
                     area_X_tensor,area_Y_tensor,
                     radial_kernel , spherical_kernel ,
                     sigma_pos , sigma_or):
    '''
    calculate the distance of two surfaces (option: current, unoriented varifold, oriented varifold)
    radial_kernel = 'Gaussian', 'Cauchy'
    spherical_kernel = 'currents', 'unoriented varifolds', 'oriented varifolds', 'distributions'
    '''
    
    ## W_xy
    W_xy = dy_surface_inner_product(verts_X_tensor, verts_Y_tensor,
                                   normal_X_tensor, normal_Y_tensor,
                                   cur_X_tensor,cur_Y_tensor,
                                   area_X_tensor,area_Y_tensor,
                                   radial_kernel = radial_kernel, spherical_kernel = spherical_kernel,
                                   sigma_pos=sigma_pos , sigma_or=sigma_or )
    
    ## W_xx
    W_xx = dy_surface_inner_product(verts_X_tensor, verts_X_tensor,
                                   normal_X_tensor, normal_X_tensor, 
                                   cur_X_tensor,cur_X_tensor,
                                   area_X_tensor,area_X_tensor,
                                   radial_kernel = radial_kernel, spherical_kernel = spherical_kernel,
                                   sigma_pos=sigma_pos , sigma_or=sigma_or)

    ## W_yy
    W_yy = dy_surface_inner_product(verts_Y_tensor, verts_Y_tensor,
                                   normal_Y_tensor, normal_Y_tensor,
                                   cur_Y_tensor,cur_Y_tensor,
                                   area_Y_tensor,area_Y_tensor,
                                   radial_kernel = radial_kernel, spherical_kernel = spherical_kernel,
                                   sigma_pos=sigma_pos , sigma_or=sigma_or )
    Dist_xy = W_xx + W_yy - 2 * W_xy
    Dist_xy = Dist_xy*(((W_xx)/(W_yy))**(0.5))
    #m=newmse(verts_X_tensor,verts_Y_tensor,area_X_tensor,area_Y_tensor)
    print('70')
    #Dist_xy=Dist_xy+m
    return Dist_xy





def landmark_distance(landmarks_X_tensor, landmarks_Y_tensor):
    '''
    calculate the distance of two groups of landmarks
    '''  
    distance_list = torch.sum((landmarks_X_tensor - landmarks_Y_tensor) ** 2, dim = 1)
    return torch.sum((distance_list + 1e-16) ** 0.5) / distance_list.shape[0]


def smoothloss(y_pred):
    dy = torch.abs(y_pred[:,:,1:, :, :] - y_pred[:,:, :-1, :, :])
    dx = torch.abs(y_pred[:,:,:, 1:, :] - y_pred[:,:, :, :-1, :])
    dz = torch.abs(y_pred[:,:,:, :, 1:] - y_pred[:,:, :, :, :-1])
    return (torch.mean(dx * dx)+torch.mean(dy*dy)+torch.mean(dz*dz))/3.0


def bdloss(y_pred):
    #y_pred = flow_disp_lvl1_lvl3_size.permute(0,2,3,4,1)
    #sample_grid = model.grid_1
    J = y_pred.permute(0,2,3,4,1)

    dz = J[:, 2:, 1:-1, 1:-1, :] - J[:, :-2, 1:-1, 1:-1, :]
    dz = dz * 0.5
    dy = J[:, 1:-1, 2:, 1:-1, :] - J[:, 1:-1, :-2, 1:-1, :]
    dy = dy * 0.5
    dx = J[:, 1:-1, 1:-1, 2:, :] - J[:, 1:-1, 1:-1, :-2, :]
    dx = dx * 0.5

    Jacobian = torch.cat((dx.unsqueeze(-1),dy.unsqueeze(-1),dz.unsqueeze(-1)), -1)
    Jacobian_tranpose_sum = Jacobian + torch.transpose(Jacobian, -2, -1)

    bd_matrix = torch.flatten(Jacobian_tranpose_sum, start_dim=-2)
    bd = torch.mean(torch.sqrt(torch.sum(bd_matrix * bd_matrix + 1e-16, dim=-1)))
    #bd = torch.mean(torch.sum(bd_matrix * bd_matrix, dim=-1))
    return bd

def JacboianDet(y_pred, sample_grid):
    J = y_pred + sample_grid
    
    dz = J[:, :, 1:, :-1, :-1] - J[:, :, :-1, :-1, :-1]
    dy = J[:, :, :-1, 1:, :-1] - J[:, :, :-1, :-1, :-1]
    dx = J[:, :, :-1, :-1, 1:] - J[:, :, :-1, :-1, :-1]

    Jdet0 = dx[:,0,:,:,:] * (dy[:,1,:,:,:] * dz[:,2,:,:,:] - dy[:,2,:,:,:] * dz[:,1,:,:,:])
    Jdet1 = dx[:,1,:,:,:] * (dy[:,0,:,:,:] * dz[:,2,:,:,:] - dy[:,2,:,:,:] * dz[:,0,:,:,:])
    Jdet2 = dx[:,2,:,:,:] * (dy[:,0,:,:,:] * dz[:,1,:,:,:] - dy[:,1,:,:,:] * dz[:,0,:,:,:])
    
    Jdet = Jdet0 - Jdet1 + Jdet2
    '''
    dz = J[:, 1:, :-1, :-1, :] - J[:, :-1, :-1, :-1, :]
    dy = J[:, :-1, 1:, :-1, :] - J[:, :-1, :-1, :-1, :]
    dx = J[:, :-1, :-1, 1:, :] - J[:, :-1, :-1, :-1, :]

    Jdet0 = dx[:,:,:,:,0] * (dy[:,:,:,:,1] * dz[:,:,:,:,2] - dy[:,:,:,:,2] * dz[:,:,:,:,1])
    Jdet1 = dx[:,:,:,:,1] * (dy[:,:,:,:,0] * dz[:,:,:,:,2] - dy[:,:,:,:,2] * dz[:,:,:,:,0])
    Jdet2 = dx[:,:,:,:,2] * (dy[:,:,:,:,0] * dz[:,:,:,:,1] - dy[:,:,:,:,1] * dz[:,:,:,:,0])
    
    Jdet_o = Jdet0 - Jdet1 + Jdet2
    '''
    return Jdet


def neg_Jdet_loss(y_pred, sample_grid):
    neg_Jdet = -1.0 * JacboianDet(y_pred, sample_grid)
    selected_neg_Jdet = F.relu(neg_Jdet)

    return torch.mean(selected_neg_Jdet)

def scaling_loss(y_pred, sample_grid, label):
    selected_scaling_ratio = torch.abs(JacboianDet(y_pred, sample_grid) - 1.) * label[:,:,1:,1:,1:]
    selected_scaling_ratio = torch.abs(torch.abs(JacboianDet(y_pred, sample_grid)) - 1.) * label[:,:,1:,1:,1:]

    return torch.mean(selected_scaling_ratio)


def transformation_fold_loss(y_pred, sample_grid):
    J = y_pred + sample_grid
    
    dz = J[:, :, 1:, :-1, :-1] - J[:, :, :-1, :-1, :-1]
    dy = J[:, :, :-1, 1:, :-1] - J[:, :, :-1, :-1, :-1]
    dx = J[:, :, :-1, :-1, 1:] - J[:, :, :-1, :-1, :-1]
    
    loss = torch.mean(F.relu(-1.0 * dx[:,0,:,:,:])) + torch.mean(F.relu(-1.0 * dy[:,1,:,:,:])) + torch.mean(F.relu(-1.0 * dz[:,2,:,:,:]))

    return loss

def pdist_squared(x):
    xx = (x**2).sum(dim=1).unsqueeze(2)
    yy = xx.permute(0, 2, 1)
    dist = xx + yy - 2.0 * torch.bmm(x.permute(0, 2, 1), x)
    dist[dist != dist] = 0
    dist = torch.clamp(dist, 0.0, np.inf)
    return dist

def MINDSSC(img, radius=2, dilation=2):
    # see http://mpheinrich.de/pub/miccai2013_943_mheinrich.pdf for details on the MIND-SSC descriptor
    # kernel size
    kernel_size = radius * 2 + 1
    
    # define start and end locations for self-similarity pattern
    six_neighbourhood = torch.Tensor([[0,1,1],
                                      [1,1,0],
                                      [1,0,1],
                                      [1,1,2],
                                      [2,1,1],
                                      [1,2,1]]).long()
    
    # squared distances
    dist = pdist_squared(six_neighbourhood.t().unsqueeze(0)).squeeze(0)
    
    # define comparison mask
    x, y = torch.meshgrid(torch.arange(6), torch.arange(6))
    mask = ((x > y).view(-1) & (dist == 2).view(-1))
    
    # build kernel
    idx_shift1 = six_neighbourhood.unsqueeze(1).repeat(1,6,1).view(-1,3)[mask,:]
    idx_shift2 = six_neighbourhood.unsqueeze(0).repeat(6,1,1).view(-1,3)[mask,:]
    mshift1 = torch.zeros(12, 1, 3, 3, 3).cuda()
    mshift1.view(-1)[torch.arange(12) * 27 + idx_shift1[:,0] * 9 + idx_shift1[:, 1] * 3 + idx_shift1[:, 2]] = 1
    mshift2 = torch.zeros(12, 1, 3, 3, 3).cuda()
    mshift2.view(-1)[torch.arange(12) * 27 + idx_shift2[:,0] * 9 + idx_shift2[:, 1] * 3 + idx_shift2[:, 2]] = 1
    rpad1 = nn.ReplicationPad3d(dilation)
    rpad2 = nn.ReplicationPad3d(radius)
    
    # compute patch-ssd
    ssd = F.avg_pool3d(rpad2((F.conv3d(rpad1(img), mshift1, dilation=dilation) - F.conv3d(rpad1(img), mshift2, dilation=dilation)) ** 2), kernel_size, stride=1)
    
    # MIND equation
    mind = ssd - torch.min(ssd, 1, keepdim=True)[0]
    mind_var = torch.mean(mind, 1, keepdim=True)
    mind_var = torch.clamp(mind_var, mind_var.mean()*0.001, mind_var.mean()*1000)
    #print((mind_var == torch.zeros(mind_var.shape).to(mind_var.device)).sum())
    #mind_var += 0.01
    mind_var = torch.where(mind_var==0, torch.ones(mind_var.shape).to(mind_var.device), mind_var)
    mind /= mind_var
    mind = torch.where(torch.isnan(mind), torch.zeros(mind.shape).to(mind.device), mind)
    '''
    print(mind_var != torch.zeros(mind_var.shape).to(mind_var.device))
    if mind_var != torch.zeros(mind_var.shape).to(mind_var.device):
        mind /= mind_var
    else:
        mind = 0
    '''
    mind = torch.exp(-mind)
    
    #permute to have same ordering as C++ code
    mind = mind[:, torch.Tensor([6, 8, 1, 11, 2, 10, 0, 7, 9, 4, 5, 3]).long(), :, :, :]
    
    return mind

def mind_loss(x, y):
    return torch.mean( (MINDSSC(x) - MINDSSC(y)) ** 2 )

def generate_grid(imgshape):
    x = np.arange(imgshape[0])
    y = np.arange(imgshape[1])
    z = np.arange(imgshape[2])
    grid = np.rollaxis(np.array(np.meshgrid(z, y, x)), 0, 4)
    grid = np.swapaxes(grid, 0, 2)
    grid = np.swapaxes(grid, 1, 2)
    return grid

def sampling_grid(size):
    vectors = [ torch.arange(0, s) for s in size ] 
    grids = torch.meshgrid(vectors) 
    grid  = torch.stack(grids) # y, x, z
    grid  = torch.unsqueeze(grid, 0)  #add batch
    grid = grid.type(torch.FloatTensor)
    return grid



class GaussianSmoothing(nn.Module):
    """
    Apply gaussian smoothing on a
    1d, 2d or 3d tensor. Filtering is performed seperately for each channel
    in the input using a depthwise convolution.
    Arguments:
        channels (int, sequence): Number of channels of the input tensors. Output will
            have this number of channels as well.
        kernel_size (int, sequence): Size of the gaussian kernel.
        sigma (float, sequence): Standard deviation of the gaussian kernel.
        dim (int, optional): The number of dimensions of the data.
            Default value is 2 (spatial).
    """
    def __init__(self, channels, kernel_size, sigma, dim=2):
        super(GaussianSmoothing, self).__init__()
        if isinstance(kernel_size, numbers.Number):
            kernel_size = [kernel_size] * dim
        if isinstance(sigma, numbers.Number):
            sigma = [sigma] * dim

        # The gaussian kernel is the product of the
        # gaussian function of each dimension.
        kernel = 1
        meshgrids = torch.meshgrid(
            [
                torch.arange(size, dtype=torch.float32)
                for size in kernel_size
            ]
        )
        for size, std, mgrid in zip(kernel_size, sigma, meshgrids):
            mean = (size - 1) / 2
            kernel *= 1 / (std * math.sqrt(2 * math.pi)) * \
                      torch.exp(-((mgrid - mean) / std) ** 2 / 2)

        # Make sure sum of values in gaussian kernel equals 1.
        kernel = kernel / torch.sum(kernel)

        # Reshape to depthwise convolutional weight
        kernel = kernel.view(1, 1, *kernel.size())
        kernel = kernel.repeat(channels, *[1] * (kernel.dim() - 1))

        self.register_buffer('weight', kernel)
        self.groups = channels

        if dim == 1:
            self.conv = F.conv1d
        elif dim == 2:
            self.conv = F.conv2d
        elif dim == 3:
            self.conv = F.conv3d
        else:
            raise RuntimeError(
                'Only 1, 2 and 3 dimensions are supported. Received {}.'.format(dim)
            )

    def forward(self, input):
        """
        Apply gaussian filter to input.
        Arguments:
            input (torch.Tensor): Input to apply gaussian filter on.
        Returns:
            filtered (torch.Tensor): Filtered output.
        """
        return self.conv(input, weight=self.weight, groups=self.groups)





class SpatialTransformer(nn.Module):
    """
    [SpatialTransformer] represesents a spatial transformation block
    that uses the output from the UNet to preform an grid_sample
    https://pytorch.org/docs/stable/nn.functional.html#grid-sample
    """
    def __init__(self, size, mode='bilinear'):
        """
        Instiatiate the block
            :param size: size of input to the spatial transformer block
            :param mode: method of interpolation for grid_sampler
        """
        super(SpatialTransformer, self).__init__()

        # Create sampling grid
        vectors = [ torch.arange(0, s) for s in size ] 
        grids = torch.meshgrid(vectors) 
        grid  = torch.stack(grids) # y, x, z
        grid  = torch.unsqueeze(grid, 0)  #add batch
        grid = grid.type(torch.FloatTensor)
        self.register_buffer('grid', grid)

        self.mode = mode

    def forward(self, src, flow):   
        """
        Push the src and flow through the spatial transform block
            :param src: the original moving image
            :param flow: the flow
        """
        new_locs = self.grid + flow 

        shape = flow.shape[2:]

        # Need to normalize grid values to [-1, 1] for resampler
        for i in range(len(shape)):
            new_locs[:,i,...] = 2*(new_locs[:,i,...]/(shape[i]-1) - 0.5)

        if len(shape) == 2:
            new_locs = new_locs.permute(0, 2, 3, 1) 
            new_locs = new_locs[..., [1,0]]
        elif len(shape) == 3:
            new_locs = new_locs.permute(0, 2, 3, 4, 1) 
            new_locs = new_locs[..., [2,1,0]]

        return torch.nn.functional.grid_sample(src, new_locs, mode=self.mode, align_corners=True)
    
def loss_plot_save(loss, save_path):
    plt.figure()
    plt.plot(range(loss.shape[1]), loss[0], label='loss_total')
    plt.plot(range(loss.shape[1]), loss[1], label='loss_surface')
    plt.plot(range(loss.shape[1]), loss[2], label='loss_landmark')
    plt.plot(range(loss.shape[1]), loss[3], label='loss_smooth')
    plt.plot(range(loss.shape[1]), loss[4], label='loss_bd')
    plt.plot(range(loss.shape[1]), loss[5], label='loss_negJdet')
    plt.plot(range(loss.shape[1]), loss[6], label='loss_negGrad')
    #plt.plot(range(loss.shape[1]), loss[7], label='loss_scaling')
    

    for i in range(6, loss.shape[0]):
        plt.plot(range(loss.shape[1]), loss[i], label='loss_' + str(i))

    plt.legend()
    plt.xlabel('step')
    plt.ylabel('loss')

    plt.savefig(save_path)

    


def dice(x_label, y_label):
    top = 2 * (x_label * y_label).sum()
    bottom = x_label.sum() + y_label.sum()
    dice =  top / bottom
    return dice

def neg_Jdet_ratio(y_pred, sample_grid):
    jac_det = JacboianDet(y_pred, sample_grid)
    return torch.mean((jac_det <= 0).float())



#此函数用来衡量配准效果
def mse(moving_vert_list,fixed_vert_list):
    vert_number1=moving_vert_list.shape[0]
    vert_number2=fixed_vert_list.shape[0]
    sum=0
    for i in range(vert_number1):
        v1=moving_vert_list[i]
        v2=fixed_vert_list[0]
        d0=v1-v2
        dis0=np.dot(d0,d0)
        for j in range(vert_number2):
            v3=fixed_vert_list[j]
            d=v1-v3
            dis=np.dot(d,d)
            if dis<dis0:
                dis0=dis
        sum=sum+dis0
    sum=sum/vert_number1      
    vert_number2=moving_vert_list.shape[0]
    vert_number1=fixed_vert_list.shape[0]
    sum2=0
    for i in range(vert_number1):
        v1=fixed_vert_list[i]
        v2=moving_vert_list[0]
        d0=v1-v2
        dis0=np.dot(d0,d0)
        for j in range(vert_number2):
            v3=moving_vert_list[j]
            d=v1-v3
            dis=np.dot(d,d)
            if dis<dis0:
                dis0=dis
        sum2=sum2+dis0
    sum2=sum2/vert_number1
    print('sum1:',sum,"sum2:",sum2)
    return sum


#此函数用于辅助计算ssim无实际意义
def mse2(moving_vert_list,fixed_vert_list,m1,m2):
    vert_number1=moving_vert_list.shape[0]
    vert_number2=fixed_vert_list.shape[0]
    sum=0
    for i in range(vert_number1):
        v1=moving_vert_list[i]
        v2=fixed_vert_list[0]
        d0=v1-v2
        dis0=np.dot(d0,d0)
        dis10=np.dot(v1-m1,v2-m2)
        for j in range(vert_number2):
            v3=fixed_vert_list[j]
            d=v1-v3
            dis=np.dot(d,d)
            dis1=np.dot(v1-m1,v3-m2)
            if dis<dis0:
                dis0=dis
                dis10=dis1
        sum=sum+dis10
    sum=sum/vert_number1      
    vert_number2=moving_vert_list.shape[0]
    vert_number1=fixed_vert_list.shape[0]
    sum2=0
    for i in range(vert_number1):
        v1=fixed_vert_list[i]
        v2=moving_vert_list[0]
        d0=v1-v2
        dis0=np.dot(d0,d0)
        dis10=np.dot(v1-m2,v2-m1)
        for j in range(vert_number2):
            v3=moving_vert_list[j]
            d=v1-v3
            dis=np.dot(d,d)
            dis1=np.dot(v1-m2,v3-m1)
            if dis<dis0:
                dis0=dis
                dis10=dis1
        sum2=sum2+dis10
    sum2=sum2/vert_number1
    return (sum+sum2)/2

#此函数用于衡量配准效果    
def ssim(list1,list2):
    m1=0
    v1=0
    number1=list1.shape[0]
    for i in range(number1):
        m1=m1+list1[i]/number1
    for i in range(number1):
        d=m1-list1[i]
        dis=np.dot(d,d)
        v1=v1+dis/number1
        
    m2=0
    v2=0
    number2=list2.shape[0]
    for i in range(number2):
        m2=m2+list2[i]/number2
    for i in range(number2):
        d=m2-list2[i]
        dis=np.dot(d,d)
        v2=v2+dis/number2
        
    c=mse2(list1,list2,m1,m2)
    
    a1=np.dot(m1,m2)
    a2=np.dot(m1,m1)
    a3=np.dot(m2,m2)
    f=(2*a1)*(2*c)/((a2+a3)*(v1+v2))
    print(f)
    
    
    
    


